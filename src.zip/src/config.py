# src/config.py
from dataclasses import dataclass
from pathlib import Path

@dataclass
class Config:
    # label for this run (any string)
    train_number: str = "12309"

    # input videos (your downloaded files)
    input_video_dir: Path = Path("DHN-wagon/Raw_video")

    # where outputs go
    out_root: Path = Path("Processed_Video")

    # processing params
    frame_sample_stride: int = 5          # take every Nth frame
    coverage_overlap: float = 0.15        # overlap between slices

    # detection (set True only if you have weights and want YOLO)
    use_yolo: bool = False
    yolo_weights: Path = Path("models/head_detection/weights/best.pt")  # change path if needed

CFG = Config()
