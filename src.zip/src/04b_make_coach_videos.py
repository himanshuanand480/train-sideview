# src/04b_make_coach_videos.py
from pathlib import Path
import cv2
import re

TRAIN_NO = "12309"  # change if your assignment says different number
FRAMES_ROOT = Path("DHN-wagon") / "Processed_Video"
OUT_VIDS = FRAMES_ROOT / "coach_videos"
OUT_VIDS.mkdir(exist_ok=True, parents=True)

def natkey(p: Path):
    # natural sort by filename: frame_2 < frame_10
    parts = re.split(r'(\d+)', p.name)
    return [int(x) if x.isdigit() else x.lower() for x in parts]

def gather_images(wagon_dir: Path):
    # 1) prefer coverage/ if present
    cov = wagon_dir / "coverage"
    if cov.exists():
        imgs = sorted([*cov.glob("*.jpg"), *cov.glob("*.jpeg"), *cov.glob("*.png")], key=natkey)
        if imgs:
            return imgs
    # 2) otherwise, accept any jpg/png in the wagon folder
    imgs = sorted([*wagon_dir.glob("*.jpg"), *wagon_dir.glob("*.jpeg"), *wagon_dir.glob("*.png")], key=natkey)
    return imgs

def make_video_for_wagon(wagon_dir: Path, fps=12):
    imgs = gather_images(wagon_dir)
    if not imgs:
        return 0, None

    # infer wagon number
    name = wagon_dir.name  # e.g., wagon23
    digits = "".join(c for c in name if c.isdigit()) or "0"
    out_path = OUT_VIDS / f"{TRAIN_NO}_{digits}.mp4"

    # size from first frame
    im0 = cv2.imread(str(imgs[0]))
    if im0 is None:
        return 0, None
    h, w = im0.shape[:2]
    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    vw = cv2.VideoWriter(str(out_path), fourcc, fps, (w, h))

    written = 0
    for f in imgs:
        im = cv2.imread(str(f))
        if im is None:
            continue
        if im.shape[0] != h or im.shape[1] != w:
            im = cv2.resize(im, (w, h))
        vw.write(im)
        written += 1
    vw.release()
    return written, out_path

def main():
    wagons = [d for d in FRAMES_ROOT.iterdir() if d.is_dir() and d.name.startswith("wagon")]
    wagons.sort(key=lambda p: int("".join([c for c in p.name if c.isdigit()]) or "0"))

    made = 0
    for w in wagons:
        n, outp = make_video_for_wagon(w)
        if n > 0:
            print(f"{w.name} -> {outp}  ({n} images)")
            made += 1
        else:
            print(f"{w.name}: no usable images, skipped.")
    print(f"\n Created {made} coach videos in {OUT_VIDS}")

if __name__ == "__main__":
    main()