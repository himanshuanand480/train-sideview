# src/05_detect_components.py
from pathlib import Path
import csv
from ultralytics import YOLO

PROCESSED = Path("DHN-wagon") / "Processed_Video"
#keep the path clean and portable
WEIGHTS = Path("DHN-wagon") / "models" / "head_detection" / "weights" / "best.pt"  # change if needed

def detect_folder(model: YOLO, wagon_dir: Path):
    imgs = sorted(wagon_dir.glob("frame_*.jpg"))
    if not imgs:
        return 0

    out_det = wagon_dir / "detected"
    out_det.mkdir(exist_ok=True)

    # csv: image, n_boxes, max_conf
    csv_path = wagon_dir / "detections.csv"
    with open(csv_path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["image", "n_boxes", "max_conf"])

        for im in imgs:
            res = model.predict(str(im), conf=0.25, verbose=False)
            r0 = res[0]
            n = 0
            maxc = 0.0
            if r0.boxes is not None and len(r0.boxes) > 0:
                n = len(r0.boxes)
                try:
                    maxc = float(r0.boxes.conf.max().item())
                except Exception:
                    maxc = 0.0
            # save annotated
            r0.save(filename=str(out_det / im.name))
            w.writerow([im.name, n, f"{maxc:.4f}"])
    return 1

def main():
    if not PROCESSED.exists():
        print(" Frames not found. Run 04_extract_frames.py first.")
        return
    if not WEIGHTS.exists():
        print(f" Weights not found: {WEIGHTS}")
        return

    model = YOLO(str(WEIGHTS))
    wagons = [d for d in PROCESSED.iterdir() if d.is_dir()]
    if not wagons:
        print(" No wagon frame folders found in Processed_Video.")
        return

    done = 0
    for w in sorted(wagons):
        print(f" Detecting components in: {w.name}")
        done += detect_folder(model, w)

    print(f"\n Detection finished for {done} wagon(s). "
          f"Check 'detected/' images and 'detections.csv' in each wagon folder.")

if __name__ == "__main__":
    main()
