# src/quick_report.py
from pathlib import Path
from datetime import datetime
import os
import html

#folders
ROOT = Path("DHN-wagon") / "wagon_frames"          # where your images actually are
OUT_DIR = Path("DHN-wagon") / "Processed_Video"    # where report.html will be written
OUT_DIR.mkdir(parents=True, exist_ok=True)
OUT_HTML = OUT_DIR / "report.html"

def rel_to_out(p: Path) -> str:
    """Browser path from OUT_DIR to the image p."""
    return os.path.relpath(p, OUT_DIR).replace("\\", "/")

def wagon_index(name: str) -> int:
    """Sort wagons naturally: wagon1, wagon2, ..., wagon47"""
    digits = "".join(ch for ch in name if ch.isdigit())
    return int(digits) if digits else 0

parts = [
    "<!doctype html><html><head><meta charset='utf-8'>",
    "<title>Train Sideview Report</title>",
    "<style>body{font-family:system-ui,Arial,sans-serif;margin:16px} ",
    "h1{margin:0 0 8px} h2{margin:24px 0 8px} ",
    ".grid{display:flex;flex-wrap:wrap;gap:6px} ",
    "img{width:240px;height:auto;border:1px solid #ccc;border-radius:6px;padding:2px}",
    "</style></head><body>",
    f"<h1>Train Sideview Report</h1><div>Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</div><hr>"
]

wagons = sorted((ROOT.glob("wagon*")), key=lambda p: wagon_index(p.name))

total_imgs = 0
for w in wagons:
    imgs = sorted([*w.glob("*.jpg"), *w.glob("*.jpeg"), *w.glob("*.png")])
    if not imgs:
        continue
    parts.append(f"<h2>{html.escape(w.name)}</h2>")
    parts.append("<div class='grid'>")
    # show up to first 40 images per wagon to keep html light
    for im in imgs[:40]:
        parts.append(f"<img src='{rel_to_out(im)}' loading='lazy' alt='{html.escape(im.name)}'>")
    parts.append("</div><hr>")
    total_imgs += len(imgs)

if total_imgs == 0:
    parts.append("<p><b>No images found.</b> Expected files in <code>DHN-wagon/wagon_frames/wagon*/</code>.</p>")

parts.append("</body></html>")
OUT_HTML.write_text("\n".join(parts), encoding="utf-8")
print(f" Simple report created: {OUT_HTML}")
