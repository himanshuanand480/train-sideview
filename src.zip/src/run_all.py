import subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
steps = [
    "01_preprocess.py",
    "02_find_coach_boundaries.py",
    "03_slice_coaches.py",
    "04_extract_frames.py",
    "05_detect_components.py",
    "06_select_coverage.py",
    "07_build_report.py",
]

for s in steps:
    script = ROOT / s
    print(f"\n=== Running {script.name} ===")
    if not script.exists():
        print(f"Step failed: {script} (file not found)")
        sys.exit(1)
    rc = subprocess.call([sys.executable, str(script)])
    if rc != 0:
        print(f"Step failed: {script} (exit {rc})")
        sys.exit(rc)

print("\n All steps completed successfully.")
