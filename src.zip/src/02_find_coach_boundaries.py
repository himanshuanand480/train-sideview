# src/02_find_coach_boundaries.py
import cv2
import os
from pathlib import Path

# Input/Output folders
ROOT = Path(__file__).resolve().parent.parent
RAW_DIR = ROOT / "DHN-wagon" / "Raw_video"
BOUNDS_DIR = ROOT / "DHN-wagon" / "coach_boundaries"
BOUNDS_DIR.mkdir(parents=True, exist_ok=True)

def find_coach_boundaries(video_path, output_txt):
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        print(f"Cannot open {video_path}")
        return

    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    print(f"Processing {video_path.name} ({frame_count} frames)")

    prev_frame = None
    diff_threshold = 25  # tweakable
    step = 5
    boundaries = [0]

    for i in range(0, frame_count, step):
        cap.set(cv2.CAP_PROP_POS_FRAMES, i)
        ret, frame = cap.read()
        if not ret:
            continue

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray = cv2.GaussianBlur(gray, (5, 5), 0)

        if prev_frame is not None:
            diff = cv2.absdiff(gray, prev_frame)
            mean_diff = diff.mean()
            if mean_diff > diff_threshold:
                boundaries.append(i)
        prev_frame = gray

    boundaries.append(frame_count)
    cap.release()

    # Save
    with open(output_txt, "w") as f:
        for b in boundaries:
            f.write(str(b) + "\n")
    print(f"Saved coach boundaries: {output_txt}")

def main():
    for video in RAW_DIR.glob("*.mp4"):
        out_txt = BOUNDS_DIR / (video.stem + "_bounds.txt")
        find_coach_boundaries(video, out_txt)

if __name__ == "__main__":
    main()
