# src/04_extract_frames.py
from pathlib import Path
import cv2

PV = Path("DHN-wagon") / "Processed_Video"
WF = Path("DHN-wagon") / "wagon_frames"

def find_mp4_sources():
    mp4s = []
    # preferred: wagon_frames/*.mp4
    mp4s += list(WF.glob("*.mp4"))
    # It also allow Processed_Video/wagon*/<something>.mp4
    for w in PV.glob("wagon*"):
        if w.is_dir():
            mp4s += list(w.glob("*.mp4"))
    return sorted(mp4s)

def ensure_wagon_dir(dst_root: Path, wagon_name: str):
    wdir = dst_root / wagon_name
    wdir.mkdir(parents=True, exist_ok=True)
    return wdir

def extract_frames(mp4_path: Path, out_dir: Path, every_n: int = 1):
    cap = cv2.VideoCapture(str(mp4_path))
    if not cap.isOpened():
        print(f"Cannot open {mp4_path.name}")
        return 0
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    count = 0
    idx = 0
    while True:
        ok, frame = cap.read()
        if not ok: break
        if idx % every_n == 0:
            count += 1
            out_file = out_dir / f"frame_{count:03d}.jpg"
            cv2.imwrite(str(out_file), frame)
        idx += 1
    cap.release()
    print(f"{mp4_path.name}: saved {count} frames -> {out_dir}")
    return count

def main():
    sources = find_mp4_sources()
    if not sources:
        # If there are already images in wagon dirs, that’s fine.
        has_images = any(list(WF.glob("wagon*/*.jpg")) + list(PV.glob("wagon*/*.jpg")))
        if has_images:
            print("No .mp4 found, but wagon images exist — skipping extraction.")
        else:
            print(f" No wagon videos found to extract. Nothing to do.")
        return

    # save frames under wagon_frames/wagonN
    for mp4 in sources:
        # infer wagon name from file name
        name = mp4.stem
        wagon = name if name.startswith("wagon") else f"wagon_{name}"
        out_dir = ensure_wagon_dir(WF, wagon)
        extract_frames(mp4, out_dir, every_n=1)

if __name__ == "__main__":
    main()
