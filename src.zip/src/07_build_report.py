# src/07_build_report.py
from pathlib import Path
from datetime import datetime
import os
import webbrowser

PROCESSED = Path("DHN-wagon") / "Processed_Video"
REPORT = PROCESSED / "report.html"

def build_report():
    wagons = sorted([d for d in PROCESSED.iterdir() if d.is_dir() and d.name.startswith("wagon")])
    total_frames = 0
    engines = [w.name for w in wagons if "engine" in w.name.lower() or int(''.join(filter(str.isdigit, w.name)) or 0) <= 2]

    html = [
        "<html><head><title>Train Sideview Report</title>",
        "<style>",
        "body { font-family: Arial, sans-serif; margin: 30px; background: #fafafa; }",
        "h1 { color: #333; }",
        "h2 { color: #444; margin-top: 30px; }",
        "img { width: 280px; margin: 4px; border-radius: 10px; box-shadow: 0 0 4px rgba(0,0,0,0.3); }",
        ".summary { background: #e8f4ff; padding: 15px; border-radius: 12px; margin-bottom: 20px; }",
        "</style></head><body>",
        "<h1>Train Sideview Report</h1>",
        f"<p>Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>",
    ]

    # Summary section
    frame_counts = []
    for w in wagons:
        cov = w / "coverage"
        n = len(list(cov.glob("*.jpg")))
        total_frames += n
        frame_counts.append((w.name, n))

    html.append("<div class='summary'>")
    html.append(f"<h2>Summary</h2>")
    html.append(f"<p><b>Total Wagons:</b> {len(wagons)}</p>")
    html.append(f"<p><b>Total Frames Selected:</b> {total_frames}</p>")
    html.append(f"<p><b>Engines Found:</b> {', '.join(engines) if engines else 'N/A'}</p>")
    html.append("</div>")

    # Each wagon
    for w, count in frame_counts:
        html.append(f"<h2>{w} ({count} frames)</h2>")
        cov_dir = PROCESSED / w / "coverage"
        for img in sorted(cov_dir.glob("*.jpg")):
            rel = os.path.relpath(img, PROCESSED).replace('\\', '/')
            html.append(f"<img src='{rel}' alt='{img.name}'>")

    html.append("</body></html>")

    REPORT.write_text("\n".join(html), encoding="utf-8")
    print(f" Wrote report: {REPORT}")
    import webbrowser
    webbrowser.open(REPORT.resolve().as_uri())

if __name__ == "__main__":
    build_report()
