# src/04_extract_frames.py
import cv2
import sys
from pathlib import Path
from dataclasses import dataclass

@dataclass
class Config:
    wagon_videos_root: Path = Path("DHN-wagon") / "wagon_frames"     # saved wagon_XX.mp4
    out_root: Path = Path(s"DHN-wagon") / "Processed_Video"           #  we will save frames
    frame_stride: int = 5                                            # save every Nth frame

CFG = Config()

def extract_frames_from_video(video_path: Path, out_dir: Path, stride: int) -> int:
    """Extract frames every `stride` frames from `video_path` into `out_dir`."""
    out_dir.mkdir(parents=True, exist_ok=True)
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        print(f"Cannot open video: {video_path}")
        return 0

    total = 0
    idx = 0
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        if idx % stride == 0:
            fname = out_dir / f"frame_{idx:06d}.jpg"
            cv2.imwrite(str(fname), frame)
            total += 1
        idx += 1
    cap.release()
    return total

def main():
    print(f"Looking for wagon videos in: {CFG.wagon_videos_root.resolve()}")

    if not CFG.wagon_videos_root.exists():
        print("wagon_videos_root does not exist. Run 03_slice_coaches.py first.")
        sys.exit(1)

    # We support two layouts:
    # A) DHN-wagon/wagon_frames/<video_id>/wagon_XX.mp4
    # B) DHN-wagon/wagon_frames/wagonXX/*.mp4  (current 'wagon47' case)
    wagon_video_files = []

    # Layout A
    for sub in CFG.wagon_videos_root.glob("*"):
        if sub.is_dir():
            wagon_video_files += list(sub.glob("wagon_*.mp4"))

    # Layout B fallback (e.g., wagon47 contains .mp4 )
    if not wagon_video_files:
        wagon_video_files = list(CFG.wagon_videos_root.glob("**/*.mp4"))

    if not wagon_video_files:
        print("No wagon videos found to extract. Nothing to do.")
        return

    print(f"Output root: {CFG.out_root.resolve()}")
    CFG.out_root.mkdir(parents=True, exist_ok=True)

    grand_total = 0
    for vp in sorted(wagon_video_files):
        # Create a stable wagon name
        # If path is .../<video_id>/wagon_12.mp4 -> wagon_<video_id>_12
        # If path is .../wagon47/xxx.mp4       -> wagon47_xxx
        parent = vp.parent.name
        stem = vp.stem  # without .mp4
        wagon_name = f"{parent}_{stem}"

        out_dir = CFG.out_root / wagon_name
        print(f"Extracting frames from {vp.name} -> {out_dir.name}")
        n = extract_frames_from_video(vp, out_dir, CFG.frame_stride)
        print(f"   Saved {n} frames")
        grand_total += n

    print(f"\n Done. Total frames saved: {grand_total}")
    print(f"   Check: {CFG.out_root.resolve()}")
    print("   (You should see folders like wagon47_<something>/frame_000000.jpg, ... )")

if __name__ == "__main__":
    main()
