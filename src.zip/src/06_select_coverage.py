# src/06_select_coverage.py
from pathlib import Path
import shutil, csv
from math import ceil

FRAMES_PER_WAGON = 12  # tweak as you like

PV = Path("DHN-wagon") / "Processed_Video"
WF = Path("DHN-wagon") / "wagon_frames"

def pick_image_root():
    # Prefer Processed_Video if it has wagon dirs with images
    pv_wagons = [d for d in PV.glob("wagon*") if d.is_dir()]
    if pv_wagons and any(list(d.glob("*.jpg")) + list(d.glob("*.png")) for d in pv_wagons):
        print(f" Using image source: {PV}")
        return PV
    # fallback to wagon_frames
    wf_wagons = [d for d in WF.glob("wagon*") if d.is_dir()]
    if wf_wagons and any(list(d.glob("*.jpg")) + list(d.glob("*.png")) for d in wf_wagons):
        print(f" Using image source: {WF}")
        return WF
    # last fallback: raw PV
    print(f" Using image source: {PV} (fallback)")
    return PV

def read_topk_from_csv(csv_path: Path, k: int, frames_dir: Path):
    rows = []
    with open(csv_path, newline="") as f:
        r = csv.DictReader(f)
        for row in r:
            try:
                rows.append((row["image"], int(row.get("n_boxes", 0)), float(row.get("max_conf", 0.0))))
            except Exception:
                pass
    if not rows:
        return []
    rows.sort(key=lambda x: (x[1], x[2]), reverse=True)
    picks = [frames_dir / r[0] for r in rows[:k]]
    return [p for p in picks if p.exists()]

def evenly_spaced(frames, k):
    if not frames:
        return []
    if k >= len(frames):
        return frames
    step = len(frames) / k
    idxs = [ceil(i * step) - 1 for i in range(1, k + 1)]
    return [frames[i] for i in idxs]

def collect_all_images(wagon_dir: Path):
    # accept any name: frame_*.jpg, *.jpg, *.png, *_complete.jpg
    imgs = []
    imgs += list(wagon_dir.glob("frame_*.jpg"))
    imgs += list(wagon_dir.glob("*.jpg"))
    imgs += list(wagon_dir.glob("*.png"))
    # ensure uniqueness & sorted
    seen = set()
    unique = []
    for p in sorted(imgs):
        if p.suffix.lower() not in [".jpg", ".jpeg", ".png"]:
            continue
        if p in seen:
            continue
        seen.add(p)
        unique.append(p)
    return unique

def main():
    img_root = pick_image_root()
    wagons = sorted([d for d in img_root.glob("wagon*") if d.is_dir()], key=lambda p: (len(p.name), p.name))

    if not wagons:
        print(" No wagon folders.")
        return

    for w in wagons:
        frames = collect_all_images(w)
        if not frames:
            print(f" No frames in {w.name}, skipping.")
            continue

        csv_path = w / "detections.csv"
        if csv_path.exists():
            picks = read_topk_from_csv(csv_path, FRAMES_PER_WAGON, w)
        else:
            picks = []

        if not picks:
            picks = evenly_spaced(frames, FRAMES_PER_WAGON)

        cov_dir = w / "coverage"
        cov_dir.mkdir(exist_ok=True)
        for old in cov_dir.glob("*"):
            try: old.unlink()
            except: pass

        for p in picks:
            shutil.copy2(p, cov_dir / p.name)

        rel = cov_dir.relative_to(img_root)
        print(f" {w.name}: selected {len(picks)} frames -> {rel}")

    # convenience: also trigger report
    try:
        from build_report import build  # if you had a helper
    except Exception:
        pass
    print("\n Coverage selection done. Next: run 07_build_report.py")

if __name__ == "__main__":
    main()
